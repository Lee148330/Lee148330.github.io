文件说明
- index.html          网站主页文件
- products.json       商品数据（可通过文本编辑器修改）

简易上传到 GitHub Pages（网页版，零命令）：
1. 注册并登录 GitHub（https://github.com）。
2. 新建仓库，名字写为 yourusername.github.io（把 yourusername 换成你的用户名）。
3. 进入仓库页面，点击 "Add file" -> "Upload files"，把本压缩包内的文件全部上传并 Commit。
4. 等几分钟，然后访问 https://yourusername.github.io 查看你的网站。

或者把这些文件直接提交到你已有的静态站点托管（如 Cloudflare Pages / Netlify）。

安全提醒
- 该站点明确标注仅供角色扮演（RP）用途，禁止用于真实武器交易。